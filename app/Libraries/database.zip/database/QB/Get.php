<?php
namespace Ars\Libraries\Database\QB;
trait Get {

    /*
    |--------------------------------------------------------------------------
    | GET
    |--------------------------------------------------------------------------
    */

    public function get(
        $table = '',
        $limit = null,
        $offset = null
    ){
    
        if ($table) {
    
            $this->table = $table;
        }
    
        if ($limit !== null) {
    
            $this->limit(
                $limit,
                $offset ?? 0
            );
        }
    
        $sql =
            $this->get_compiled_select(
                $this->table,
                false
            );
    
        if (!$sql) {
    
            throw new \RuntimeException(
                'Failed compile select query'
            );
        }
    
        $this->query($sql);
    
        foreach ($this->bindings as $k => $v) {
    
            $this->bind($k, $v);
        }
    
        if (!$this->execute()) {
    
            $this->reset_qb();
    
            return false;
        }
    
        $this->reset_qb();
    
        return $this;
    }

    /*
    |--------------------------------------------------------------------------
    | GET WHERE
    |--------------------------------------------------------------------------
    */

    public function get_where(
        $table = '',
        $where = [],
        $limit = null,
        $offset = null
    ){

        if ($table) {

            $this->table = $table;
        }

        /*
        |--------------------------------------------------------------------------
        | WHERE
        |--------------------------------------------------------------------------
        */

        if (!empty($where)) {

            $this->where($where);
        }

        return $this->get(
            $this->table,
            $limit,
            $offset
        );
    }
}