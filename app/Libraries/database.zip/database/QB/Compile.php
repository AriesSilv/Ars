<?php
namespace Ars\Libraries\Database\QB;

trait Compile {

    /*
    |--------------------------------------------------------------------------
    | PROTECT IDENTIFIER
    |--------------------------------------------------------------------------
    */

    protected function protect_identifier(
        $identifier
    ){

        if ($identifier === '*') {
            return '*';
        }

        /*
        |--------------------------------------------------------------------------
        | ALREADY RAW
        |--------------------------------------------------------------------------
        */

        if (
            str_contains($identifier, '(')
            || str_contains($identifier, ')')
            || str_contains($identifier, '`')
        ) {
            return $identifier;
        }

        /*
        |--------------------------------------------------------------------------
        | ALIAS
        |--------------------------------------------------------------------------
        */

        if (stripos($identifier, ' AS ') !== false) {

            [$field, $alias] =
                preg_split(
                    '/\s+AS\s+/i',
                    $identifier
                );

            return
                $this->protect_identifier($field)
                . ' AS '
                . $this->protect_identifier($alias);
        }

        /*
        |--------------------------------------------------------------------------
        | DOT NOTATION
        |--------------------------------------------------------------------------
        */

        $parts =
            explode('.', $identifier);

        $parts =
            array_map(
                fn($part) =>
                    $part === '*'
                    ? '*'
                    : "`{$part}`",
                $parts
            );

        return implode('.', $parts);
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED SELECT
    |--------------------------------------------------------------------------
    */

    public function get_compiled_select(
        $table = '',
        $reset = true
    ){

        $table =
            $table ?: $this->from ?: $this->table;

        /*
        |--------------------------------------------------------------------------
        | AUTO CLOSE GROUP
        |--------------------------------------------------------------------------
        */

        while (!empty($this->groupStack)) {

            $this->where[] = ")";

            array_pop($this->groupStack);
        }

        /*
        |--------------------------------------------------------------------------
        | TABLE
        |--------------------------------------------------------------------------
        */

        $table =
            $this->protect_identifier($table);

        /*
        |--------------------------------------------------------------------------
        | SELECT
        |--------------------------------------------------------------------------
        */

        $sql = "SELECT ";

        if ($this->distinct) {

            $sql .= "DISTINCT ";
        }

        /*
        |--------------------------------------------------------------------------
        | SELECT FIELD
        |--------------------------------------------------------------------------
        */

        if (is_array($this->select)) {

            $select = [];

            foreach ($this->select as $field) {

                $select[] =
                    $this->protect_identifier($field);
            }

            $sql .= implode(", ", $select);

        } else {

            $sql .= $this->select;
        }

        /*
        |--------------------------------------------------------------------------
        | FROM
        |--------------------------------------------------------------------------
        */

        $sql .= " FROM {$table}";

        /*
        |--------------------------------------------------------------------------
        | JOIN
        |--------------------------------------------------------------------------
        */

        if (!empty($this->join)) {

            $sql .= " "
                . implode(" ", $this->join);
        }

        /*
        |--------------------------------------------------------------------------
        | WHERE
        |--------------------------------------------------------------------------
        */

        if (!empty($this->where)) {

            $sql .= " WHERE "
                . implode(" ", $this->where);
        }

        /*
        |--------------------------------------------------------------------------
        | GROUP BY
        |--------------------------------------------------------------------------
        */

        if (!empty($this->groupBy)) {

            $groups = [];

            foreach ($this->groupBy as $group) {

                $groups[] =
                    $this->protect_identifier($group);
            }

            $sql .= " GROUP BY "
                . implode(", ", $groups);
        }

        /*
        |--------------------------------------------------------------------------
        | HAVING
        |--------------------------------------------------------------------------
        */

        if (!empty($this->having)) {

            $sql .= " HAVING "
                . implode(" ", $this->having);
        }

        /*
        |--------------------------------------------------------------------------
        | ORDER
        |--------------------------------------------------------------------------
        */

        if (!empty($this->order)) {

            $sql .= " "
                . $this->order;
        }

        /*
        |--------------------------------------------------------------------------
        | LIMIT
        |--------------------------------------------------------------------------
        */

        if (!empty($this->limit)) {

            $sql .= " "
                . $this->limit;
        }

        if ($reset) {

            $this->reset_qb();
        }

        return $sql;
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED INSERT
    |--------------------------------------------------------------------------
    */

    public function get_compiled_insert(
        $table = '',
        $reset = true
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        $fields = [];

        $params = [];

        foreach ($this->set as $set) {

            preg_match(
                '/^(.+?)\s*=\s*:(\w+)$/',
                $set,
                $match
            );

            $field =
                trim($match[1] ?? '');

            $param =
                $match[2] ?? '';

            if (!$field || !$param) {
                continue;
            }

            $fields[] =
                $field;

            $params[] =
                ":{$param}";
        }

        $sql =
            "INSERT INTO {$table} ("
            . implode(", ", $fields)
            . ") VALUES ("
            . implode(", ", $params)
            . ")";

        if ($reset) {

            $this->reset_qb();
        }

        return $sql;
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED UPDATE
    |--------------------------------------------------------------------------
    */

    public function get_compiled_update(
        $table = '',
        $reset = true
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        if (empty($this->set)) {

            throw new \Exception(
                "UPDATE tanpa SET"
            );
        }

        if (empty($this->where)) {

            throw new \Exception(
                "UPDATE tanpa WHERE berbahaya"
            );
        }

        $sql =
            "UPDATE {$table} SET "
            . implode(", ", $this->set);

        $sql .= " WHERE "
            . implode(" ", $this->where);

        if ($reset) {

            $this->reset_qb();
        }

        return $sql;
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED DELETE
    |--------------------------------------------------------------------------
    */

    public function get_compiled_delete(
        $table = '',
        $reset = true
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        if (empty($this->where)) {

            throw new \Exception(
                "DELETE tanpa WHERE berbahaya"
            );
        }

        $sql =
            "DELETE FROM {$table}";

        $sql .= " WHERE "
            . implode(" ", $this->where);

        if ($reset) {

            $this->reset_qb();
        }

        return $sql;
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED TRUNCATE
    |--------------------------------------------------------------------------
    */

    public function get_compiled_truncate(
        $table = ''
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        return "TRUNCATE {$table}";
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED EMPTY TABLE
    |--------------------------------------------------------------------------
    */

    public function get_compiled_empty_table(
        $table = ''
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        return "DELETE FROM {$table}";
    }

    /*
    |--------------------------------------------------------------------------
    | COMPILED REPLACE
    |--------------------------------------------------------------------------
    */

    public function get_compiled_replace(
        $table = '',
        $reset = true
    ){

        $table =
            $table ?: $this->table;

        $table =
            $this->protect_identifier($table);

        if (empty($this->set)) {

            throw new \Exception(
                'REPLACE membutuhkan data SET'
            );
        }

        $fields = [];

        $params = [];

        foreach ($this->set as $set) {

            preg_match(
                '/^(.+?)\s*=\s*:(\w+)$/',
                $set,
                $match
            );

            $field =
                trim($match[1] ?? '');

            $param =
                $match[2] ?? '';

            if (!$field || !$param) {
                continue;
            }

            $fields[] =
                $field;

            $params[] =
                ":{$param}";
        }

        $sql =
            "REPLACE INTO {$table} ("
            . implode(", ", $fields)
            . ") VALUES ("
            . implode(", ", $params)
            . ")";

        if ($reset) {

            $this->reset_qb();
        }

        return $sql;
    }

}